import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const SERVER_ROOT = path.resolve(__dirname, '..');

dotenv.config({ path: path.join(SERVER_ROOT, '.env') });

export const config = {
  port: Number(process.env.PORT) || 5000,

  openrouterKey: process.env.OPENROUTER_API_KEY || '',
  openrouterBaseUrl: process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
  discoveryModel: process.env.DISCOVERY_MODEL || 'openai/gpt-4o-mini',
  emailModel: process.env.EMAIL_MODEL || 'openai/gpt-4o-mini',
  useWebSearch: String(process.env.USE_WEB_SEARCH).toLowerCase() !== 'false',

  dataDir: path.join(SERVER_ROOT, 'data'),
  maxLeads: 30,

  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT) || 465,
    secure: String(process.env.SMTP_SECURE ?? 'true').toLowerCase() === 'true',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    from: process.env.SMTP_FROM || process.env.SMTP_USER || '',
  },
  testRecipient: process.env.TEST_RECIPIENT || '',
};
