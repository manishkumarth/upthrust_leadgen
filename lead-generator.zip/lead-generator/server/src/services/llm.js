import { config } from '../config.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Thin OpenRouter chat-completions client with retries.
 * Returns { content, citations } where citations are URLs from the web-search plugin (if used).
 */
export async function chat({ model, messages, temperature = 0.4, plugins, maxTokens, retries = 2 }) {
  if (!config.openrouterKey) {
    throw new Error('OPENROUTER_API_KEY is not set. Add it to server/.env');
  }

  const body = { model, messages, temperature };
  if (plugins) body.plugins = plugins;
  if (maxTokens) body.max_tokens = maxTokens;

  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(`${config.openrouterBaseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.openrouterKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'http://localhost:5173',
          'X-Title': 'Outbound Lead Generator',
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(150_000),
      });

      if (res.status === 429 || res.status >= 500) {
        throw Object.assign(new Error(`OpenRouter ${res.status}`), { retryable: true });
      }
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`OpenRouter ${res.status}: ${text.slice(0, 300)}`);
      }

      const data = await res.json();
      if (data.error) throw new Error(`OpenRouter: ${data.error.message || JSON.stringify(data.error)}`);

      const msg = data.choices?.[0]?.message || {};
      const citations = (msg.annotations || [])
        .filter((a) => a.type === 'url_citation')
        .map((a) => a.url_citation?.url)
        .filter(Boolean);

      return { content: msg.content || '', citations };
    } catch (e) {
      lastErr = e;
      const retryable = e.retryable || e.name === 'TimeoutError' || e.name === 'TypeError';
      if (!retryable || attempt === retries) break;
      await sleep(1500 * (attempt + 1));
    }
  }
  throw lastErr;
}

/** Pull a JSON value out of an LLM reply (handles ```json fences and surrounding prose). */
export function extractJson(text) {
  if (!text) return null;
  const cleaned = text.replace(/```(?:json)?/gi, '').trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    /* fall through */
  }
  const first = cleaned.search(/[[{]/);
  if (first === -1) return null;
  const close = cleaned[first] === '[' ? ']' : '}';
  const last = cleaned.lastIndexOf(close);
  if (last <= first) return null;
  try {
    return JSON.parse(cleaned.slice(first, last + 1));
  } catch {
    return null;
  }
}
