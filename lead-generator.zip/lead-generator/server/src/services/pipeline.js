import { findLeads } from './leadFinder.js';
import { generateEmail } from './emailWriter.js';
import * as store from './store.js';

async function mapLimit(items, limit, worker) {
  let i = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (i < items.length) {
        const idx = i++;
        await worker(items[idx], idx);
      }
    }),
  );
}

/** Runs in the background: discover leads -> write an email for each -> mark campaign completed. */
export async function runCampaign(campaignId) {
  const campaign = store.getCampaign(campaignId);
  if (!campaign) return;

  const progress = (message, done = campaign.progress.done) => {
    campaign.progress = { message, done, total: campaign.numberOfLeads };
    store.saveCampaign(campaign);
  };

  try {
    const { leads, warnings } = await findLeads(campaign, (msg) => progress(msg, 0));
    campaign.warnings = warnings;

    if (!leads.length) {
      throw new Error(
        'No verifiable organizations were found. Try rephrasing the industry or product, or check the API key / model.',
      );
    }

    campaign.leads = leads.map((l) => ({
      id: store.newId(),
      ...l,
      emailSubject: '',
      emailBody: '',
      emailGeneratedBy: '',
      status: 'Not Contacted',
      contactedAt: '',
    }));
    campaign.progress = { message: 'Writing personalized emails…', done: 0, total: campaign.leads.length };
    store.saveCampaign(campaign);

    let done = 0;
    await mapLimit(campaign.leads, 3, async (lead) => {
      const email = await generateEmail(campaign, lead);
      lead.emailSubject = email.subject;
      lead.emailBody = email.body;
      lead.emailGeneratedBy = email.generatedBy;
      done += 1;
      campaign.progress = { message: `Writing personalized emails… (${done}/${campaign.leads.length})`, done, total: campaign.leads.length };
      store.saveCampaign(campaign);
    });

    campaign.status = 'completed';
    campaign.progress = { message: 'Done', done: campaign.leads.length, total: campaign.leads.length };
    store.saveCampaign(campaign);
  } catch (e) {
    campaign.status = 'failed';
    campaign.error = e.message;
    store.saveCampaign(campaign);
  }
}
