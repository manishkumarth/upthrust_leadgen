import * as cheerio from 'cheerio';

const UA =
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// Social / directory / aggregator hosts are never "the organization's own website".
export const BLOCKED_HOSTS = [
  'facebook.com', 'instagram.com', 'linkedin.com', 'twitter.com', 'x.com', 'youtube.com',
  'wikipedia.org', 'justdial.com', 'indiamart.com', 'crunchbase.com', 'glassdoor.com',
  'yelp.com', 'google.com', 'maps.google.com', 'tripadvisor.com', 'zaubacorp.com',
  'sulekha.com', 'shiksha.com', 'collegedunia.com', 'naukri.com', 'indeed.com',
];

const ROLE_PREFERENCE = [
  'info', 'contact', 'hello', 'sales', 'enquiry', 'enquiries', 'admissions', 'office',
  'admin', 'support', 'principal', 'reception', 'team',
];
const EXCLUDED_PREFIXES = ['webmaster', 'abuse', 'postmaster', 'privacy', 'noreply', 'no-reply', 'donotreply'];
const BAD_SUBSTRINGS = [
  'sentry', 'example.', 'yourdomain', 'domain.com', 'email.com', 'wixpress', 'godaddy',
  'your@', 'name@', 'user@', 'test@', 'yourname', 'sample',
];
const BAD_EXT = /\.(png|jpe?g|gif|svg|webp|css|js|ico|woff2?|ttf|pdf)$/i;
const EMAIL_RE = /[a-z0-9._%+-]+@[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}/gi;
const FREE_MAIL = ['gmail.com', 'yahoo.com', 'yahoo.in', 'hotmail.com', 'outlook.com', 'rediffmail.com'];

/** Turn whatever the LLM gave us into { origin, host, url } or null. */
export function normalizeWebsite(input) {
  if (!input || typeof input !== 'string') return null;
  let s = input.trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  try {
    const u = new URL(s);
    if (!u.hostname.includes('.')) return null;
    const host = u.hostname.replace(/^www\./i, '').toLowerCase();
    if (BLOCKED_HOSTS.some((b) => host === b || host.endsWith(`.${b}`))) return null;
    return { origin: u.origin, host, url: `${u.origin}/` };
  } catch {
    return null;
  }
}

export async function fetchPage(url, timeoutMs = 10_000) {
  try {
    const res = await fetch(url, {
      redirect: 'follow',
      headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'en' },
      signal: AbortSignal.timeout(timeoutMs),
    });
    const type = res.headers.get('content-type') || '';
    if (!res.ok) return { ok: false, status: res.status, finalUrl: res.url, error: `HTTP ${res.status}` };
    if (!/html|xml/i.test(type)) return { ok: false, status: res.status, finalUrl: res.url, error: 'not html' };
    const html = (await res.text()).slice(0, 1_500_000);
    return { ok: true, status: res.status, finalUrl: res.url, html };
  } catch (e) {
    const code = e.cause?.code || e.code || e.name;
    return { ok: false, status: 0, error: String(code || e.message), dns: ['ENOTFOUND', 'EAI_AGAIN'].includes(code) };
  }
}

// Cloudflare "email protection" obfuscation
function decodeCfEmail(hex) {
  try {
    const key = parseInt(hex.slice(0, 2), 16);
    let out = '';
    for (let i = 2; i < hex.length; i += 2) out += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16) ^ key);
    return out;
  } catch {
    return '';
  }
}

function sameSite(emailDomain, host) {
  return emailDomain === host || emailDomain.endsWith(`.${host}`) || host.endsWith(`.${emailDomain}`);
}

export function extractEmails(html, host) {
  const $ = cheerio.load(html);
  const found = new Set();

  $('a[href^="mailto:"]').each((_, el) => {
    const raw = ($(el).attr('href') || '').replace(/^mailto:/i, '').split('?')[0];
    decodeURIComponent(raw)
      .split(/[,;]/)
      .forEach((e) => found.add(e.trim()));
  });
  $('[data-cfemail]').each((_, el) => found.add(decodeCfEmail($(el).attr('data-cfemail') || '')));

  const deobfuscated = html
    .replace(/\s*[[(]\s*at\s*[\])]\s*/gi, '@')
    .replace(/\s*[[(]\s*dot\s*[\])]\s*/gi, '.');
  (deobfuscated.match(EMAIL_RE) || []).forEach((e) => found.add(e));

  const cleaned = [...found]
    .map((e) => e.toLowerCase().replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, ''))
    .filter((e) => /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/.test(e))
    .filter((e) => !BAD_EXT.test(e))
    .filter((e) => !BAD_SUBSTRINGS.some((b) => e.includes(b)))
    .filter((e) => !EXCLUDED_PREFIXES.some((p) => e.startsWith(`${p}@`)));

  const score = (e) => {
    const [local, domain] = e.split('@');
    let s = 0;
    if (sameSite(domain, host)) s += 10;
    else if (FREE_MAIL.includes(domain)) s += 2;
    const idx = ROLE_PREFERENCE.indexOf(local);
    if (idx !== -1) s += 5 - Math.min(idx, 4) * 0.5;
    return s;
  };

  return [...new Set(cleaned)].sort((a, b) => score(b) - score(a));
}

/**
 * Visit the organization's homepage (+ contact/about pages if needed).
 * Returns reachability info, page context for the email writer, and any contact emails found.
 */
export async function enrichSite(site) {
  let page = await fetchPage(site.url);
  if (!page.ok && page.status === 0 && !page.dns && site.url.startsWith('https://')) {
    const alt = await fetchPage(site.url.replace('https://', 'http://'));
    if (alt.ok) page = alt;
  }
  if (!page.ok) {
    return { reachable: false, dns: !!page.dns, error: page.error, emails: [], emailSource: '' };
  }

  const base = page.finalUrl || site.url;
  const $ = cheerio.load(page.html);
  const title = $('title').first().text().replace(/\s+/g, ' ').trim();
  const metaDesc = (
    $('meta[name="description"]').attr('content') ||
    $('meta[property="og:description"]').attr('content') ||
    ''
  ).trim();
  const siteName = ($('meta[property="og:site_name"]').attr('content') || '').trim();

  let emails = extractEmails(page.html, site.host);
  let emailSource = emails.length ? base : '';

  if (!emails.length) {
    // look for contact/about pages linked from the homepage, then fall back to common paths
    const links = [];
    $('a[href]').each((_, el) => {
      const href = $(el).attr('href') || '';
      if (!/contact|reach-us|get-in-touch|about/i.test(href)) return;
      try {
        const u = new URL(href, base);
        if (u.hostname.replace(/^www\./, '') === site.host) links.push(u.origin + u.pathname);
      } catch {
        /* ignore bad href */
      }
    });
    links.sort((a, b) => Number(/contact/i.test(b)) - Number(/contact/i.test(a)));
    const guesses = [`${site.origin}/contact`, `${site.origin}/contact-us`];
    const targets = [...new Set([...links, ...guesses])].slice(0, 3);

    const pages = await Promise.all(targets.map((t) => fetchPage(t, 8000)));
    for (let i = 0; i < pages.length; i++) {
      if (!pages[i].ok) continue;
      const found = extractEmails(pages[i].html, site.host);
      if (found.length) {
        emails = found;
        emailSource = targets[i];
        break;
      }
    }
  }

  $('script,style,noscript,svg,iframe,nav,footer').remove();
  const text = $('body').text().replace(/\s+/g, ' ').trim().slice(0, 1500);

  return { reachable: true, finalUrl: base, title, metaDesc, siteName, text, emails, emailSource };
}
