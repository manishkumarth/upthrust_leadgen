import { chat, extractJson } from './llm.js';
import { config } from '../config.js';
import { normalizeWebsite, enrichSite } from './scraper.js';

const SYSTEM_PROMPT = `You are a B2B lead-research assistant for a marketing agency. You have web search.
Your job: find REAL organizations that would realistically buy a given SaaS product.

Rules:
- Only return organizations you actually found via search. Never invent organizations or domains.
- "website" must be the organization's OWN official website (homepage), not a social profile, directory, or news article.
- Match the target country and industry exactly. Prefer organizations with the size/structure that would actually need and pay for the product (decision-makers exist, budget plausible).
- Favor a diverse mix (different cities/regions, different sizes) over many near-duplicates.
- "description" = 1-2 factual sentences about what the organization does (size, location, specialties if known). No marketing fluff.
- "source_url" = the page where you found/confirmed the organization.
- Respond with ONLY a JSON array, no prose. Each item:
  {"name": string, "website": string, "city": string, "description": string, "source_url": string}`;

const ROUND_HINTS = [
  'Start with the most prominent and well-documented organizations that fit.',
  'Focus on DIFFERENT cities/regions and mid-sized organizations than those already found.',
  'Include smaller or lesser-known but legitimate organizations, again in new cities/regions.',
];

async function pool(items, limit, worker) {
  const results = new Array(items.length);
  let i = 0;
  await Promise.all(
    Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (i < items.length) {
        const idx = i++;
        results[idx] = await worker(items[idx], idx);
      }
    }),
  );
  return results;
}

async function discover(campaign, count, excludeNames, round) {
  const user = [
    `Product being sold: ${campaign.productDescription}`,
    `Target country: ${campaign.country}`,
    `Target industry: ${campaign.industry}`,
    `Find ${count} organizations that would be strong potential customers.`,
    ROUND_HINTS[Math.min(round - 1, ROUND_HINTS.length - 1)],
    excludeNames.length ? `Already found (do NOT repeat): ${excludeNames.join('; ')}` : '',
  ]
    .filter(Boolean)
    .join('\n');

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: user },
  ];

  const base = { model: config.discoveryModel, messages, temperature: 0.3, maxTokens: 4000 };
  let res;
  try {
    res = await chat({ ...base, plugins: config.useWebSearch ? [{ id: 'web', max_results: 10 }] : undefined });
  } catch (e) {
    if (!config.useWebSearch) throw e;
    // web plugin unavailable for this key/model -> degrade gracefully (website verification still filters fakes)
    res = await chat(base);
  }

  let parsed = extractJson(res.content);
  if (parsed && !Array.isArray(parsed)) parsed = parsed.leads || parsed.organizations || parsed.results || [];
  if (!Array.isArray(parsed)) return { items: [], citations: res.citations };
  return { items: parsed.filter((p) => p && typeof p === 'object'), citations: res.citations };
}

function pickSourceUrl(candidate, site, citations) {
  try {
    if (candidate.source_url) return new URL(candidate.source_url).href;
  } catch {
    /* fall through */
  }
  const match = citations.find((c) => {
    try {
      return new URL(c).hostname.replace(/^www\./, '').endsWith(site.host);
    } catch {
      return false;
    }
  });
  return match || citations[0] || site.origin;
}

function toLead(candidate, site, info, campaign, citations) {
  const name = String(candidate.name || '').trim() || info.siteName || site.host;
  return {
    organizationName: name,
    website: info.reachable && info.finalUrl ? new URL(info.finalUrl).origin : site.origin,
    country: campaign.country,
    industry: campaign.industry,
    contactEmail: info.emails?.[0] || '',
    description: String(candidate.description || '').trim() || info.metaDesc || '',
    sourceUrl: pickSourceUrl(candidate, site, citations),
    city: String(candidate.city || '').trim(),
    verified: !!info.reachable,
    emailSource: info.emailSource || '',
    // used only to personalize the email; not exported
    context: info.reachable
      ? { title: info.title, metaDescription: info.metaDesc, pageText: (info.text || '').slice(0, 1200) }
      : { title: '', metaDescription: '', pageText: '' },
  };
}

/**
 * Discover -> verify -> enrich loop.
 * Over-fetches candidates, drops domains that don't resolve, scrapes contact emails,
 * and ranks verified leads that have an email first.
 */
export async function findLeads(campaign, onProgress = () => {}) {
  const n = campaign.numberOfLeads;
  const accepted = new Map(); // host -> lead
  const seenHosts = new Set();
  const names = [];
  const warnings = [];

  for (let round = 1; round <= 3; round++) {
    const ask = Math.min(30, Math.max(12, Math.ceil(n * 1.8)));
    onProgress(`Searching the web for organizations (round ${round}/3)…`);

    let found;
    try {
      found = await discover(campaign, ask, names, round);
    } catch (e) {
      if (accepted.size === 0 && round === 1) throw e;
      warnings.push(`Discovery round ${round} failed: ${e.message}`);
      break;
    }

    const fresh = [];
    for (const c of found.items) {
      const site = normalizeWebsite(c.website);
      if (!site || seenHosts.has(site.host)) continue;
      seenHosts.add(site.host);
      if (c.name) names.push(String(c.name));
      fresh.push({ c, site });
    }

    onProgress(`Verifying ${fresh.length} websites and looking for contact emails…`);
    const enriched = await pool(fresh, 5, async ({ c, site }) => ({ c, site, info: await enrichSite(site) }));

    for (const { c, site, info } of enriched) {
      if (info.dns) continue; // domain doesn't exist -> hallucinated, drop
      accepted.set(site.host, toLead(c, site, info, campaign, found.citations));
    }

    const all = [...accepted.values()];
    const withEmail = all.filter((l) => l.contactEmail).length;
    onProgress(`Found ${all.length} verified organizations so far (${withEmail} with a contact email)…`);
    if (all.length >= n && withEmail >= Math.ceil(n * 0.7)) break;
  }

  const rank = (l) => (l.verified ? 2 : 0) + (l.contactEmail ? 4 : 0);
  const leads = [...accepted.values()].sort((a, b) => rank(b) - rank(a)).slice(0, n);

  if (leads.length < n) {
    warnings.push(`Only ${leads.length} of ${n} requested leads could be verified. Try broadening the industry or country text.`);
  }
  return { leads, warnings };
}
