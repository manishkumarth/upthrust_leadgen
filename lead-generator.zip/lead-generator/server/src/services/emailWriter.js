import { chat, extractJson } from './llm.js';
import { config } from '../config.js';

const SYSTEM_PROMPT = `You write cold outreach emails for a B2B marketing agency on behalf of a SaaS startup.

Style rules:
- 90-130 words in the body. Plain text, short paragraphs, no bullet lists, no emojis, no markdown.
- Open with ONE specific, genuine observation about the recipient organization, taken ONLY from the facts provided. Never invent facts, numbers, customers, awards or case studies.
- Connect that observation to ONE concrete problem the product solves, and state the benefit plainly.
- No filler ("I hope this email finds you well", "I came across your company"), no hype, no ALL CAPS, no false urgency.
- End with ONE clear, low-friction call to action (e.g. a 15-minute call or a quick reply), offering a concrete next step.
- Subject: max 8 words, specific to the recipient, no clickbait, no exclamation marks.
- Greeting: "Hi <Organization> team," (we do not know a person's name).
- Sign off with the sender name (and startup name if given).

Respond with ONLY JSON: {"subject": string, "body": string}. Use \\n for line breaks inside body.`;

function buildUserPrompt(campaign, lead) {
  const lines = [
    `Product: ${campaign.productDescription}`,
    campaign.companyName ? `Startup name: ${campaign.companyName}` : 'Startup name: (not given - refer to the product generically)',
    `Sender name: ${campaign.senderName || 'The Team'}`,
    '',
    `Recipient organization: ${lead.organizationName}`,
    `Country: ${lead.country}`,
    lead.city ? `City: ${lead.city}` : '',
    `Industry: ${lead.industry}`,
    `Website: ${lead.website}`,
    `What we know about them: ${lead.description || '(little known)'}`,
    lead.context?.title ? `Homepage title: ${lead.context.title}` : '',
    lead.context?.metaDescription ? `Homepage description: ${lead.context.metaDescription}` : '',
    lead.context?.pageText ? `Homepage excerpt: ${lead.context.pageText}` : '',
  ];
  return lines.filter((l) => l !== '').join('\n');
}

function fallbackEmail(campaign, lead) {
  const sender = campaign.senderName || 'The Team';
  const product = campaign.companyName ? `${campaign.companyName}` : 'our product';
  return {
    subject: `Idea for ${lead.organizationName}`,
    body:
      `Hi ${lead.organizationName} team,\n\n` +
      `${lead.description ? `${lead.description.split('. ')[0].replace(/\.$/, '')}. ` : ''}` +
      `We help organizations like yours with this: ${campaign.productDescription}.\n\n` +
      `Would you be open to a 15-minute call next week to see if ${product} could be useful for you?\n\n` +
      `Best regards,\n${sender}${campaign.companyName ? `\n${campaign.companyName}` : ''}`,
  };
}

/** Generate a personalized cold email. Never throws: falls back to a simple template. */
export async function generateEmail(campaign, lead) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: buildUserPrompt(campaign, lead) },
  ];

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await chat({ model: config.emailModel, messages, temperature: 0.7, maxTokens: 700 });
      const json = extractJson(res.content);
      const subject = typeof json?.subject === 'string' ? json.subject.trim() : '';
      const body = typeof json?.body === 'string' ? json.body.replace(/\\n/g, '\n').trim() : '';
      if (subject && body.length > 40) return { subject, body, generatedBy: 'llm' };
    } catch {
      /* retry, then fall back */
    }
  }
  return { ...fallbackEmail(campaign, lead), generatedBy: 'template' };
}
