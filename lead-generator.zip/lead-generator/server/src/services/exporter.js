import ExcelJS from 'exceljs';

export const COLUMNS = [
  { header: 'Organization Name', key: 'organizationName', width: 32 },
  { header: 'Website', key: 'website', width: 32 },
  { header: 'Country', key: 'country', width: 14 },
  { header: 'Industry', key: 'industry', width: 22 },
  { header: 'Contact Email', key: 'contactEmail', width: 30 },
  { header: 'Description', key: 'description', width: 50 },
  { header: 'Source URL', key: 'sourceUrl', width: 40 },
  { header: 'Email Subject', key: 'emailSubject', width: 40 },
  { header: 'Email Body', key: 'emailBody', width: 70 },
  { header: 'Status', key: 'status', width: 16 },
  { header: 'Contacted At', key: 'contactedAt', width: 22 },
];

const csvCell = (v) => {
  const s = v == null ? '' : String(v);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function toCsv(leads) {
  const rows = [COLUMNS.map((c) => csvCell(c.header)).join(',')];
  for (const lead of leads) rows.push(COLUMNS.map((c) => csvCell(lead[c.key])).join(','));
  // BOM so Excel opens UTF-8 correctly
  return `﻿${rows.join('\r\n')}\r\n`;
}

export async function toXlsxBuffer(leads, sheetName = 'Leads') {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(sheetName, { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = COLUMNS.map((c) => ({ header: c.header, key: c.key, width: c.width }));
  leads.forEach((l) => ws.addRow(COLUMNS.reduce((o, c) => ({ ...o, [c.key]: l[c.key] ?? '' }), {})));

  ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
  ws.eachRow((row, i) => {
    row.alignment = { vertical: 'top', wrapText: true };
    if (i === 1) row.alignment = { vertical: 'middle' };
  });
  ws.autoFilter = { from: 'A1', to: { row: 1, column: COLUMNS.length } };

  return wb.xlsx.writeBuffer();
}
