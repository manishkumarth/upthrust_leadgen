import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { toCsv } from './exporter.js';

const DB_FILE = path.join(config.dataDir, 'db.json');
const EXPORT_DIR = path.join(config.dataDir, 'exports');

let db = { campaigns: [] };

export const newId = () => crypto.randomUUID();

export function init() {
  fs.mkdirSync(EXPORT_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch {
      db = { campaigns: [] };
    }
  }
  // anything that was mid-run when the server stopped can't resume
  for (const c of db.campaigns) {
    if (c.status === 'running') {
      c.status = 'failed';
      c.error = 'Server restarted while this campaign was running.';
    }
  }
  persist();
}

function persist(campaign) {
  const tmp = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
  // keep a ready-to-open CSV of every campaign on disk (data/exports/campaign-<id>.csv)
  const targets = campaign ? [campaign] : db.campaigns;
  for (const c of targets) {
    fs.writeFileSync(path.join(EXPORT_DIR, `campaign-${c.id}.csv`), toCsv(c.leads || []));
  }
}

export function createCampaign(input) {
  const campaign = {
    id: newId().slice(0, 8),
    createdAt: new Date().toISOString(),
    ...input,
    status: 'running',
    progress: { message: 'Starting…', done: 0, total: input.numberOfLeads },
    warnings: [],
    error: null,
    leads: [],
  };
  db.campaigns.unshift(campaign);
  persist(campaign);
  return campaign;
}

export const getCampaign = (id) => db.campaigns.find((c) => c.id === id) || null;

export function listCampaigns() {
  return db.campaigns.map((c) => ({
    id: c.id,
    createdAt: c.createdAt,
    status: c.status,
    productDescription: c.productDescription,
    country: c.country,
    industry: c.industry,
    numberOfLeads: c.numberOfLeads,
    leadCount: c.leads.length,
    contactedCount: c.leads.filter((l) => l.status === 'Contacted').length,
  }));
}

export const saveCampaign = (campaign) => persist(campaign);

export function deleteCampaign(id) {
  const idx = db.campaigns.findIndex((c) => c.id === id);
  if (idx === -1) return false;
  db.campaigns.splice(idx, 1);
  persist();
  try {
    fs.rmSync(path.join(EXPORT_DIR, `campaign-${id}.csv`), { force: true });
  } catch {
    /* ignore */
  }
  return true;
}

export function findLead(leadId) {
  for (const campaign of db.campaigns) {
    const lead = campaign.leads.find((l) => l.id === leadId);
    if (lead) return { campaign, lead };
  }
  return null;
}
