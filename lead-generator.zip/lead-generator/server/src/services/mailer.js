import nodemailer from 'nodemailer';
import { config } from '../config.js';

let cached; // { transporter, mode, from }

async function getTransport() {
  if (cached) return cached;

  if (config.smtp.host) {
    cached = {
      mode: 'smtp',
      from: config.smtp.from,
      transporter: nodemailer.createTransport({
        host: config.smtp.host,
        port: config.smtp.port,
        secure: config.smtp.secure,
        auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined,
      }),
    };
  } else {
    // Test mode: throwaway Ethereal inbox. Nothing reaches real people; we return a preview URL.
    const acct = await nodemailer.createTestAccount();
    cached = {
      mode: 'test',
      from: `Lead Generator <${acct.user}>`,
      transporter: nodemailer.createTransport({
        host: acct.smtp.host,
        port: acct.smtp.port,
        secure: acct.smtp.secure,
        auth: { user: acct.user, pass: acct.pass },
      }),
    };
  }
  return cached;
}

export const mailMode = () => (config.smtp.host ? 'smtp' : 'test');

export async function sendMail({ to, subject, text }) {
  const { transporter, mode, from } = await getTransport();
  const actualTo = config.testRecipient || to;
  const info = await transporter.sendMail({ from, to: actualTo, subject, text });
  return {
    mode,
    sentTo: actualTo,
    redirected: actualTo !== to,
    messageId: info.messageId,
    previewUrl: mode === 'test' ? nodemailer.getTestMessageUrl(info) || '' : '',
  };
}
