import { Router } from 'express';
import { config } from '../config.js';
import * as store from '../services/store.js';
import { runCampaign } from '../services/pipeline.js';
import { generateEmail } from '../services/emailWriter.js';
import { toCsv, toXlsxBuffer } from '../services/exporter.js';
import { sendMail, mailMode } from '../services/mailer.js';

const router = Router();
const STATUSES = ['Not Contacted', 'Contacted'];
const EMAIL_OK = /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const fail = (res, code, error) => res.status(code).json({ error });

router.get('/config', (_req, res) => {
  res.json({
    mailMode: mailMode(), // 'smtp' = real sending, 'test' = Ethereal sandbox
    redirectingToTestRecipient: Boolean(config.testRecipient),
    discoveryModel: config.discoveryModel,
    emailModel: config.emailModel,
    webSearch: config.useWebSearch,
    maxLeads: config.maxLeads,
    hasApiKey: Boolean(config.openrouterKey),
  });
});

// ---------- campaigns ----------
router.get('/campaigns', (_req, res) => res.json(store.listCampaigns()));

router.post('/campaigns', (req, res) => {
  const b = req.body || {};
  const productDescription = String(b.productDescription || '').trim();
  const country = String(b.country || '').trim();
  const industry = String(b.industry || '').trim();
  const numberOfLeads = Number.parseInt(b.numberOfLeads, 10);

  if (productDescription.length < 10) return fail(res, 400, 'Describe the product in at least a sentence.');
  if (!country) return fail(res, 400, 'Country is required.');
  if (!industry) return fail(res, 400, 'Industry is required.');
  if (!Number.isInteger(numberOfLeads) || numberOfLeads < 1 || numberOfLeads > config.maxLeads) {
    return fail(res, 400, `Number of leads must be between 1 and ${config.maxLeads}.`);
  }

  const campaign = store.createCampaign({
    productDescription,
    country,
    industry,
    numberOfLeads,
    senderName: String(b.senderName || '').trim(),
    companyName: String(b.companyName || '').trim(),
  });

  runCampaign(campaign.id); // fire and forget; client polls GET /campaigns/:id
  res.status(201).json(campaign);
});

router.get('/campaigns/:id', (req, res) => {
  const c = store.getCampaign(req.params.id);
  if (!c) return fail(res, 404, 'Campaign not found');
  res.json(c);
});

router.delete('/campaigns/:id', (req, res) => {
  if (!store.deleteCampaign(req.params.id)) return fail(res, 404, 'Campaign not found');
  res.json({ ok: true });
});

router.get('/campaigns/:id/export.csv', (req, res) => {
  const c = store.getCampaign(req.params.id);
  if (!c) return fail(res, 404, 'Campaign not found');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="leads-${c.id}.csv"`);
  res.send(toCsv(c.leads));
});

router.get('/campaigns/:id/export.xlsx', async (req, res, next) => {
  try {
    const c = store.getCampaign(req.params.id);
    if (!c) return fail(res, 404, 'Campaign not found');
    const buf = await toXlsxBuffer(c.leads);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="leads-${c.id}.xlsx"`);
    res.send(Buffer.from(buf));
  } catch (e) {
    next(e);
  }
});

// ---------- leads ----------
router.patch('/leads/:id', (req, res) => {
  const found = store.findLead(req.params.id);
  if (!found) return fail(res, 404, 'Lead not found');
  const { campaign, lead } = found;
  const b = req.body || {};

  if (b.emailSubject !== undefined) lead.emailSubject = String(b.emailSubject);
  if (b.emailBody !== undefined) lead.emailBody = String(b.emailBody);
  if (b.contactEmail !== undefined) {
    const email = String(b.contactEmail).trim();
    if (email && !EMAIL_OK.test(email)) return fail(res, 400, 'That does not look like a valid email address.');
    lead.contactEmail = email;
  }
  if (b.status !== undefined) {
    if (!STATUSES.includes(b.status)) return fail(res, 400, `Status must be one of: ${STATUSES.join(', ')}`);
    lead.status = b.status;
    lead.contactedAt = b.status === 'Contacted' ? new Date().toISOString() : '';
  }

  store.saveCampaign(campaign);
  res.json(lead);
});

router.post('/leads/:id/regenerate', async (req, res, next) => {
  try {
    const found = store.findLead(req.params.id);
    if (!found) return fail(res, 404, 'Lead not found');
    const { campaign, lead } = found;
    const email = await generateEmail(campaign, lead);
    lead.emailSubject = email.subject;
    lead.emailBody = email.body;
    lead.emailGeneratedBy = email.generatedBy;
    store.saveCampaign(campaign);
    res.json(lead);
  } catch (e) {
    next(e);
  }
});

async function deliver(campaign, lead) {
  if (lead.status === 'Contacted') throw new Error('This lead was already contacted. Set it back to "Not Contacted" to resend.');
  if (!lead.contactEmail) throw new Error('This lead has no contact email.');
  if (!lead.emailSubject || !lead.emailBody) throw new Error('This lead has no email drafted yet.');
  const result = await sendMail({ to: lead.contactEmail, subject: lead.emailSubject, text: lead.emailBody });
  lead.status = 'Contacted';
  lead.contactedAt = new Date().toISOString();
  lead.lastSend = result;
  store.saveCampaign(campaign);
  return result;
}

router.post('/leads/:id/send', async (req, res) => {
  const found = store.findLead(req.params.id);
  if (!found) return fail(res, 404, 'Lead not found');
  try {
    const result = await deliver(found.campaign, found.lead);
    res.json({ lead: found.lead, result });
  } catch (e) {
    fail(res, 400, `Send failed: ${e.message}`);
  }
});

router.post('/campaigns/:id/send-all', async (req, res) => {
  const campaign = store.getCampaign(req.params.id);
  if (!campaign) return fail(res, 404, 'Campaign not found');

  const targets = campaign.leads.filter((l) => l.status !== 'Contacted' && l.contactEmail && l.emailBody);
  const summary = { attempted: targets.length, sent: 0, failed: [], skippedNoEmail: campaign.leads.filter((l) => !l.contactEmail).length };

  for (const lead of targets) {
    try {
      await deliver(campaign, lead);
      summary.sent += 1;
    } catch (e) {
      summary.failed.push({ id: lead.id, organizationName: lead.organizationName, error: e.message });
    }
    await sleep(1000); // be gentle with SMTP providers
  }
  res.json({ summary, campaign });
});

export default router;
