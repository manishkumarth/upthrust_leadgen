import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { config, SERVER_ROOT } from './config.js';
import * as store from './services/store.js';
import api from './routes/api.js';

store.init();

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api', api);

// If the React app has been built (npm run build), serve it from this same port.
const clientDist = path.resolve(SERVER_ROOT, '../client/dist');
if (fs.existsSync(path.join(clientDist, 'index.html'))) {
  app.use(express.static(clientDist));
  app.get(/^\/(?!api).*/, (_req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

app.listen(config.port, () => {
  console.log(`Lead generator API running on http://localhost:${config.port}`);
  if (!config.openrouterKey) console.warn('⚠  OPENROUTER_API_KEY missing - add it to server/.env');
});
