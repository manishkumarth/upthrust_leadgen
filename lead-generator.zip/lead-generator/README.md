# Outbound Lead Generator

Internal agency tool: **campaign input → lead discovery → personalized emails → CSV / Excel → email outreach**.

Stack: React + Tailwind CSS (Vite) · Node.js + Express · plain JavaScript · OpenRouter for LLM calls.

## Run it

Requires Node 18+.

```bash
npm run install:all     # installs root, server and client dependencies
npm run dev             # API on :5000, web app on http://localhost:5173
```

`server/.env` already contains the OpenRouter key. For a single-port run: `npm run build && npm start`, then open http://localhost:5000.

## How to use

1. Open http://localhost:5173. Fill in product, country, industry, number of leads (or click one of the three example chips).
2. Watch progress. Leads and emails appear as they are produced (1-3 min for 10 leads).
3. Click **View email** to read/edit/regenerate a draft. Edits are saved to the lead.
4. **Send** one lead, or **Send all**. Status flips to *Contacted* with a timestamp.
5. **Export CSV / Excel** any time. A CSV for every campaign is also kept in `server/data/exports/`.

## How leads are found (and why they're real)

1. **Discovery**: an LLM with OpenRouter's *web search plugin* proposes organizations, each with its official site and the source page. Up to 3 rounds, each told what was already found so results diversify across cities/sizes.
2. **Verification**: every website is fetched. Domains that don't resolve (hallucinations), social/directory sites (LinkedIn, Justdial…), and duplicates are dropped. Deep links are normalized to the homepage.
3. **Contact email extraction**: the homepage, then linked/guessed `/contact` pages are scraped for emails (`mailto:`, plain text, `[at]`/`[dot]` obfuscation, Cloudflare-encoded). Image filenames and junk (`sentry`, `example.com`, `noreply`…) are filtered, and addresses on the organization's own domain / role addresses (`info@`, `admissions@`…) are preferred.
4. **Ranking**: verified leads with an email come first, so you get the requested number of leads that are actually contactable. A warning is shown if fewer than requested could be verified.

Emails are **only ever scraped from the organization's own public pages**, never guessed or invented. If none is found the cell says "not found" and you can type one in the email modal.

## Email generation

One LLM call per lead, using the product pitch plus facts about that organization (description, homepage title/meta/excerpt). The prompt forces: one genuine, fact-based opener, one concrete benefit, no invented stats, ~100 words, one clear CTA (15-minute call), short specific subject line. If the model fails twice, a basic template is used and the lead is flagged so you can hit *Regenerate*.

## Sending email

| Mode | When | Behavior |
|---|---|---|
| **Test inbox** (default) | `SMTP_HOST` empty | Uses a throwaway [Ethereal](https://ethereal.email) account. Nothing reaches real people; you get a preview link. |
| **SMTP** | `SMTP_HOST` set in `server/.env` | Real delivery. Gmail: `smtp.gmail.com`, port `465`, secure `true`, user = your address, pass = an [app password](https://myaccount.google.com/apppasswords). |
| **Redirect** | `TEST_RECIPIENT` set | Every email is sent to that address instead of the lead. Use for safe demos with real SMTP. |

Also available per lead: **Open in mail app** (mailto link) and **Mark sent** for manual workflows. Already-contacted leads can't be re-sent unless you set them back to *Not Contacted*.

## Output columns

`Organization Name, Website, Country, Industry, Contact Email, Description, Source URL, Email Subject, Email Body, Status` (+ `Contacted At`). Status is `Not Contacted` / `Contacted`.

## Project layout

```
server/src
  index.js              Express app (serves client/dist if built)
  config.js             env + defaults
  routes/api.js         REST endpoints
  services/llm.js       OpenRouter client (retries, JSON extraction)
  services/leadFinder.js discovery → verify → enrich → rank loop
  services/scraper.js   fetch pages, extract/rank emails
  services/emailWriter.js personalized email generation (+ fallback)
  services/pipeline.js  background campaign runner
  services/store.js     JSON file store (server/data/db.json) + CSV sync
  services/exporter.js  CSV + XLSX
  services/mailer.js    nodemailer (SMTP / Ethereal)
client/src              React UI (CampaignForm, CampaignView, LeadsTable, EmailModal)
```

## API

`GET /api/config` · `GET/POST /api/campaigns` · `GET/DELETE /api/campaigns/:id` · `GET /api/campaigns/:id/export.csv|xlsx` · `POST /api/campaigns/:id/send-all` · `PATCH /api/leads/:id` · `POST /api/leads/:id/regenerate` · `POST /api/leads/:id/send`

## Configuration (`server/.env`)

`OPENROUTER_API_KEY`, `DISCOVERY_MODEL`, `EMAIL_MODEL` (default `openai/gpt-4o-mini`), `USE_WEB_SEARCH`, `PORT`, `SMTP_*`, `TEST_RECIPIENT`. See `.env.example`.

## Known limitations / next steps

- Lead quality depends on the web-search plugin; niche markets may return fewer than requested (the UI warns you).
- Sites that block bots or render emails with JavaScript only will show "not found"; a headless browser or an enrichment API (Hunter/Apollo) would be the next step.
- JSON file storage is fine for an internal tool; swap for SQLite/Postgres if volume grows.
- Cold outreach is regulated (CAN-SPAM, GDPR/PECR, India's DPDP Act). Add unsubscribe handling and honor opt-outs before real campaigns.
- `server/.env` holds the API key: don't commit it (it's in `.gitignore`).
