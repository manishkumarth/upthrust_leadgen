async function request(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

const json = (method, body) => ({ method, body: body ? JSON.stringify(body) : undefined });

export const api = {
  config: () => request('/config'),
  campaigns: () => request('/campaigns'),
  campaign: (id) => request(`/campaigns/${id}`),
  createCampaign: (body) => request('/campaigns', json('POST', body)),
  deleteCampaign: (id) => request(`/campaigns/${id}`, json('DELETE')),
  updateLead: (id, body) => request(`/leads/${id}`, json('PATCH', body)),
  regenerate: (id) => request(`/leads/${id}/regenerate`, json('POST')),
  sendLead: (id) => request(`/leads/${id}/send`, json('POST')),
  sendAll: (id) => request(`/campaigns/${id}/send-all`, json('POST')),
  exportUrl: (id, type) => `/api/campaigns/${id}/export.${type}`,
};
