import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import CampaignForm from './components/CampaignForm.jsx';
import CampaignView from './components/CampaignView.jsx';

const STATUS_DOT = {
  running: 'bg-amber-400 animate-pulse',
  completed: 'bg-emerald-500',
  failed: 'bg-red-500',
};

export default function App() {
  const [config, setConfig] = useState(null);
  const [campaigns, setCampaigns] = useState([]);
  const [activeId, setActiveId] = useState(null); // null => "new campaign" form
  const [campaign, setCampaign] = useState(null);
  const [toast, setToast] = useState(null);

  const notify = useCallback((message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  }, []);

  const refreshList = useCallback(() => api.campaigns().then(setCampaigns).catch(() => {}), []);

  useEffect(() => {
    api.config().then(setConfig).catch(() => notify('Cannot reach the API. Is the server running on :5000?', 'error'));
    refreshList();
  }, [notify, refreshList]);

  // load the selected campaign
  useEffect(() => {
    if (!activeId) {
      setCampaign(null);
      return undefined;
    }
    let alive = true;
    setCampaign((c) => (c && c.id === activeId ? c : null)); // don't flash the previously selected campaign
    api.campaign(activeId).then((c) => alive && setCampaign(c)).catch((e) => notify(e.message, 'error'));
    return () => {
      alive = false;
    };
  }, [activeId, notify]);

  // poll while a campaign is running so leads/emails appear as they are produced
  useEffect(() => {
    if (!activeId || campaign?.status !== 'running') return undefined;
    const t = setInterval(async () => {
      try {
        const c = await api.campaign(activeId);
        setCampaign(c);
        if (c.status !== 'running') refreshList();
      } catch {
        /* keep polling */
      }
    }, 2000);
    return () => clearInterval(t);
  }, [activeId, campaign?.status, refreshList]);

  const onCreated = (c) => {
    setCampaign(c);
    setActiveId(c.id);
    refreshList();
  };

  const onLeadChange = (lead) => {
    setCampaign((c) => (c ? { ...c, leads: c.leads.map((l) => (l.id === lead.id ? lead : l)) } : c));
    refreshList();
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this campaign and all its leads?')) return;
    await api.deleteCampaign(id);
    if (activeId === id) setActiveId(null);
    refreshList();
  };

  return (
    <div className="flex min-h-screen">
      <aside className="w-64 shrink-0 border-r border-slate-200 bg-white p-4">
        <h1 className="text-lg font-bold text-indigo-700">Lead Generator</h1>
        <p className="mb-4 text-xs text-slate-500">Internal agency tool</p>

        <button
          onClick={() => setActiveId(null)}
          className={`mb-4 w-full rounded-lg px-3 py-2 text-sm font-medium ${
            activeId === null ? 'bg-indigo-600 text-white' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
          }`}
        >
          + New campaign
        </button>

        <div className="space-y-1">
          {campaigns.map((c) => (
            <div
              key={c.id}
              className={`group flex items-start gap-2 rounded-lg p-2 text-sm ${
                activeId === c.id ? 'bg-slate-100' : 'hover:bg-slate-50'
              }`}
            >
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${STATUS_DOT[c.status] || 'bg-slate-300'}`} />
              <button onClick={() => setActiveId(c.id)} className="min-w-0 flex-1 text-left">
                <div className="truncate font-medium">{c.industry}</div>
                <div className="truncate text-xs text-slate-500">
                  {c.country} · {c.leadCount}/{c.numberOfLeads} leads · {c.contactedCount} contacted
                </div>
              </button>
              <button
                onClick={() => onDelete(c.id)}
                className="hidden text-slate-400 hover:text-red-600 group-hover:block"
                title="Delete campaign"
              >
                ✕
              </button>
            </div>
          ))}
          {!campaigns.length && <p className="text-xs text-slate-400">No campaigns yet.</p>}
        </div>

        {config && (
          <div className="mt-6 rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
            <div>
              Email mode:{' '}
              <span className={config.mailMode === 'smtp' ? 'font-semibold text-emerald-700' : 'font-semibold text-amber-700'}>
                {config.mailMode === 'smtp' ? 'SMTP (real)' : 'Test inbox'}
              </span>
            </div>
            {config.redirectingToTestRecipient && <div>All mail redirected to TEST_RECIPIENT</div>}
            <div className="truncate">Model: {config.discoveryModel}</div>
            {!config.hasApiKey && <div className="font-semibold text-red-600">No API key set!</div>}
          </div>
        )}
      </aside>

      <main className="min-w-0 flex-1 p-6">
        {activeId === null || !campaign ? (
          activeId === null ? (
            <CampaignForm config={config} onCreated={onCreated} notify={notify} />
          ) : (
            <p className="text-slate-500">Loading…</p>
          )
        ) : (
          <CampaignView campaign={campaign} config={config} onLeadChange={onLeadChange} onReplace={setCampaign} notify={notify} />
        )}
      </main>

      {toast && (
        <div
          className={`fixed bottom-4 right-4 max-w-md rounded-lg px-4 py-3 text-sm shadow-lg ${
            toast.type === 'error' ? 'bg-red-600 text-white' : toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-white'
          }`}
        >
          {toast.message}
        </div>
      )}
    </div>
  );
}
