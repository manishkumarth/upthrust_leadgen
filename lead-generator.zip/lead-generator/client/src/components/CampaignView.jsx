import { useMemo, useState } from 'react';
import { api } from '../api.js';
import LeadsTable from './LeadsTable.jsx';
import EmailModal from './EmailModal.jsx';

function Stat({ label, value }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-4 py-2">
      <div className="text-xl font-bold">{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}

export default function CampaignView({ campaign, config, onLeadChange, onReplace, notify }) {
  const [openLeadId, setOpenLeadId] = useState(null);
  const [onlyWithEmail, setOnlyWithEmail] = useState(false);
  const [sendingAll, setSendingAll] = useState(false);

  const running = campaign.status === 'running';
  const leads = useMemo(
    () => (onlyWithEmail ? campaign.leads.filter((l) => l.contactEmail) : campaign.leads),
    [campaign.leads, onlyWithEmail],
  );
  const withEmail = campaign.leads.filter((l) => l.contactEmail).length;
  const contacted = campaign.leads.filter((l) => l.status === 'Contacted').length;
  const sendable = campaign.leads.filter((l) => l.contactEmail && l.status !== 'Contacted' && l.emailBody).length;
  const openLead = campaign.leads.find((l) => l.id === openLeadId) || null;
  const pct = campaign.progress?.total ? Math.round((campaign.progress.done / campaign.progress.total) * 100) : 0;

  const sendAll = async () => {
    const real = config?.mailMode === 'smtp' && !config?.redirectingToTestRecipient;
    const msg = real
      ? `Send ${sendable} real emails to the leads' contact addresses now?`
      : `Send ${sendable} emails (${config?.redirectingToTestRecipient ? 'redirected to your TEST_RECIPIENT' : 'test inbox, nothing delivered to real people'})?`;
    if (!window.confirm(msg)) return;
    setSendingAll(true);
    try {
      const { summary, campaign: updated } = await api.sendAll(campaign.id);
      onReplace(updated);
      notify(
        `Sent ${summary.sent}/${summary.attempted}.` + (summary.failed.length ? ` ${summary.failed.length} failed.` : ''),
        summary.failed.length ? 'error' : 'success',
      );
    } catch (e) {
      notify(e.message, 'error');
    } finally {
      setSendingAll(false);
    }
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl font-bold">
            {campaign.industry} <span className="text-slate-400">· {campaign.country}</span>
          </h2>
          <p className="mt-1 max-w-3xl text-sm text-slate-500">{campaign.productDescription}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <a
            href={api.exportUrl(campaign.id, 'csv')}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-50"
          >
            Export CSV
          </a>
          <a
            href={api.exportUrl(campaign.id, 'xlsx')}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-50"
          >
            Export Excel
          </a>
          <button
            onClick={sendAll}
            disabled={running || sendingAll || !sendable}
            className="rounded-lg bg-indigo-600 px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-40"
          >
            {sendingAll ? 'Sending…' : `Send all (${sendable})`}
          </button>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-3">
        <Stat label="Leads" value={`${campaign.leads.length}/${campaign.numberOfLeads}`} />
        <Stat label="With contact email" value={withEmail} />
        <Stat label="Contacted" value={contacted} />
      </div>

      {running && (
        <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-4">
          <div className="mb-2 text-sm font-medium text-amber-900">{campaign.progress?.message}</div>
          <div className="h-2 overflow-hidden rounded-full bg-amber-100">
            <div className="h-full bg-amber-500 transition-all" style={{ width: `${Math.max(pct, 5)}%` }} />
          </div>
        </div>
      )}

      {campaign.status === 'failed' && (
        <div className="mb-4 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          <b>Campaign failed:</b> {campaign.error}
        </div>
      )}

      {campaign.warnings?.length > 0 && (
        <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          {campaign.warnings.map((w) => (
            <div key={w}>⚠ {w}</div>
          ))}
        </div>
      )}

      {campaign.leads.length > 0 && (
        <>
          <label className="mb-2 inline-flex items-center gap-2 text-sm text-slate-600">
            <input type="checkbox" checked={onlyWithEmail} onChange={(e) => setOnlyWithEmail(e.target.checked)} />
            Only show leads with a contact email
          </label>
          <LeadsTable leads={leads} config={config} onOpen={setOpenLeadId} onLeadChange={onLeadChange} notify={notify} />
        </>
      )}

      {openLead && (
        <EmailModal
          lead={openLead}
          config={config}
          onClose={() => setOpenLeadId(null)}
          onLeadChange={onLeadChange}
          notify={notify}
        />
      )}
    </div>
  );
}
