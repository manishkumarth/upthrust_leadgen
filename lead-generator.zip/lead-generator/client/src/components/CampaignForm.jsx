import { useState } from 'react';
import { api } from '../api.js';

const EXAMPLES = [
  {
    label: 'EdTech → Indian schools',
    productDescription: 'AI-powered student attendance software that marks attendance via face recognition and instantly notifies parents',
    country: 'India',
    industry: 'Education / Schools',
    numberOfLeads: 10,
  },
  {
    label: 'HealthTech → US hospitals',
    productDescription: 'AI patient-scheduling and no-show prediction software that fills empty appointment slots automatically',
    country: 'United States',
    industry: 'Hospitals',
    numberOfLeads: 10,
  },
  {
    label: 'HRTech → UK companies',
    productDescription: 'Recruitment software that screens CVs with AI and ranks candidates against the job description',
    country: 'United Kingdom',
    industry: 'Mid-size companies / HR departments',
    numberOfLeads: 10,
  },
];

const inputCls =
  'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200';

export default function CampaignForm({ config, onCreated, notify }) {
  const [form, setForm] = useState({ ...EXAMPLES[0], senderName: '', companyName: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const campaign = await api.createCampaign({ ...form, numberOfLeads: Number(form.numberOfLeads) });
      onCreated(campaign);
    } catch (err) {
      notify(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl">
      <h2 className="text-2xl font-bold">New campaign</h2>
      <p className="mb-4 text-sm text-slate-500">
        Describe the startup&apos;s product and who should buy it. We&apos;ll find real organizations, verify their websites,
        look for contact emails and draft a personalized cold email for each.
      </p>

      <div className="mb-4 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button
            key={ex.label}
            type="button"
            onClick={() => setForm((f) => ({ ...f, ...ex }))}
            className="rounded-full border border-slate-300 bg-white px-3 py-1 text-xs text-slate-600 hover:border-indigo-400 hover:text-indigo-700"
          >
            {ex.label}
          </button>
        ))}
      </div>

      <form onSubmit={submit} className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <label className="block">
          <span className="mb-1 block text-sm font-medium">Product description</span>
          <textarea rows={3} className={inputCls} value={form.productDescription} onChange={set('productDescription')} required />
        </label>

        <div className="grid gap-4 sm:grid-cols-3">
          <label className="block">
            <span className="mb-1 block text-sm font-medium">Country</span>
            <input className={inputCls} value={form.country} onChange={set('country')} required />
          </label>
          <label className="block">
            <span className="mb-1 block text-sm font-medium">Industry</span>
            <input className={inputCls} value={form.industry} onChange={set('industry')} required />
          </label>
          <label className="block">
            <span className="mb-1 block text-sm font-medium">Number of leads</span>
            <input
              type="number"
              min={1}
              max={config?.maxLeads || 30}
              className={inputCls}
              value={form.numberOfLeads}
              onChange={set('numberOfLeads')}
              required
            />
          </label>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="mb-1 block text-sm font-medium">
              Startup name <span className="font-normal text-slate-400">(optional)</span>
            </span>
            <input className={inputCls} placeholder="e.g. AttendAI" value={form.companyName} onChange={set('companyName')} />
          </label>
          <label className="block">
            <span className="mb-1 block text-sm font-medium">
              Sender name <span className="font-normal text-slate-400">(optional)</span>
            </span>
            <input className={inputCls} placeholder="e.g. Priya from AttendAI" value={form.senderName} onChange={set('senderName')} />
          </label>
        </div>

        <button
          disabled={busy}
          className="w-full rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {busy ? 'Starting…' : 'Generate leads & emails'}
        </button>
        <p className="text-center text-xs text-slate-400">Takes roughly 1–3 minutes depending on the number of leads.</p>
      </form>
    </div>
  );
}
