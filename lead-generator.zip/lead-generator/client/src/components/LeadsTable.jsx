import { useState } from 'react';
import { api } from '../api.js';

export function StatusBadge({ status }) {
  const contacted = status === 'Contacted';
  return (
    <span
      className={`inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ${
        contacted ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
      }`}
    >
      {status}
    </span>
  );
}

export function confirmSend(config, lead) {
  if (config?.mailMode === 'smtp' && !config?.redirectingToTestRecipient) {
    return window.confirm(`Send this email to ${lead.contactEmail}?`);
  }
  return true;
}

function host(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

export default function LeadsTable({ leads, config, onOpen, onLeadChange, notify }) {
  const [busyId, setBusyId] = useState(null);

  const send = async (lead) => {
    if (!confirmSend(config, lead)) return;
    setBusyId(lead.id);
    try {
      const { lead: updated, result } = await api.sendLead(lead.id);
      onLeadChange(updated);
      notify(
        result.previewUrl ? `Sent to test inbox. Preview: ${result.previewUrl}` : `Email sent to ${result.sentTo}`,
        'success',
      );
    } catch (e) {
      notify(e.message, 'error');
    } finally {
      setBusyId(null);
    }
  };

  const toggle = async (lead) => {
    setBusyId(lead.id);
    try {
      const updated = await api.updateLead(lead.id, {
        status: lead.status === 'Contacted' ? 'Not Contacted' : 'Contacted',
      });
      onLeadChange(updated);
    } catch (e) {
      notify(e.message, 'error');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            <th className="px-3 py-2">Organization</th>
            <th className="px-3 py-2">Contact email</th>
            <th className="px-3 py-2">Description</th>
            <th className="px-3 py-2">Email subject</th>
            <th className="px-3 py-2">Status</th>
            <th className="px-3 py-2 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {leads.map((lead) => (
            <tr key={lead.id} className="align-top hover:bg-slate-50">
              <td className="max-w-[16rem] px-3 py-3">
                <div className="font-medium">{lead.organizationName}</div>
                <a href={lead.website} target="_blank" rel="noreferrer" className="text-xs text-indigo-600 hover:underline">
                  {host(lead.website)}
                </a>
                {!lead.verified && (
                  <div className="text-xs text-amber-600" title="The website did not respond when we checked it">
                    ⚠ site unverified
                  </div>
                )}
                <div className="text-xs text-slate-400">
                  {lead.city ? `${lead.city}, ` : ''}
                  {lead.country}
                </div>
              </td>
              <td className="px-3 py-3">
                {lead.contactEmail ? (
                  <span className="break-all">{lead.contactEmail}</span>
                ) : (
                  <span className="text-xs text-slate-400">not found</span>
                )}
              </td>
              <td className="max-w-sm px-3 py-3 text-slate-600">
                <div className="line-clamp-3">{lead.description}</div>
                <a href={lead.sourceUrl} target="_blank" rel="noreferrer" className="text-xs text-indigo-600 hover:underline">
                  source: {host(lead.sourceUrl)}
                </a>
              </td>
              <td className="max-w-xs px-3 py-3">
                {lead.emailSubject ? (
                  <span className="line-clamp-2">{lead.emailSubject}</span>
                ) : (
                  <span className="text-xs italic text-slate-400">writing…</span>
                )}
              </td>
              <td className="px-3 py-3">
                <StatusBadge status={lead.status} />
              </td>
              <td className="px-3 py-3">
                <div className="flex justify-end gap-1.5">
                  <button
                    onClick={() => onOpen(lead.id)}
                    disabled={!lead.emailBody}
                    className="rounded-md border border-slate-300 px-2 py-1 text-xs font-medium hover:bg-slate-100 disabled:opacity-40"
                  >
                    View email
                  </button>
                  <button
                    onClick={() => send(lead)}
                    disabled={busyId === lead.id || !lead.contactEmail || !lead.emailBody || lead.status === 'Contacted'}
                    className="rounded-md bg-indigo-600 px-2 py-1 text-xs font-medium text-white hover:bg-indigo-700 disabled:opacity-40"
                    title={!lead.contactEmail ? 'No contact email found' : ''}
                  >
                    Send
                  </button>
                  <button
                    onClick={() => toggle(lead)}
                    disabled={busyId === lead.id}
                    className="rounded-md border border-slate-300 px-2 py-1 text-xs hover:bg-slate-100"
                    title="Manually change status (e.g. after sending from your own mail client)"
                  >
                    {lead.status === 'Contacted' ? 'Undo' : 'Mark sent'}
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
