import { useState } from 'react';
import { api } from '../api.js';
import { StatusBadge, confirmSend } from './LeadsTable.jsx';

const field =
  'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200';

export default function EmailModal({ lead, config, onClose, onLeadChange, notify }) {
  const [subject, setSubject] = useState(lead.emailSubject);
  const [body, setBody] = useState(lead.emailBody);
  const [email, setEmail] = useState(lead.contactEmail);
  const [busy, setBusy] = useState('');

  const dirty = subject !== lead.emailSubject || body !== lead.emailBody || email !== lead.contactEmail;

  const run = async (name, fn) => {
    setBusy(name);
    try {
      await fn();
    } catch (e) {
      notify(e.message, 'error');
    } finally {
      setBusy('');
    }
  };

  const save = () =>
    run('save', async () => {
      const updated = await api.updateLead(lead.id, { emailSubject: subject, emailBody: body, contactEmail: email });
      onLeadChange(updated);
      notify('Saved', 'success');
    });

  const regenerate = () =>
    run('regen', async () => {
      const updated = await api.regenerate(lead.id);
      onLeadChange(updated);
      setSubject(updated.emailSubject);
      setBody(updated.emailBody);
      setEmail(updated.contactEmail);
    });

  const send = () =>
    run('send', async () => {
      if (!confirmSend(config, { ...lead, contactEmail: email })) return;
      if (dirty) await api.updateLead(lead.id, { emailSubject: subject, emailBody: body, contactEmail: email });
      const { lead: updated, result } = await api.sendLead(lead.id);
      onLeadChange(updated);
      notify(result.previewUrl ? `Sent to test inbox. Preview: ${result.previewUrl}` : `Email sent to ${result.sentTo}`, 'success');
    });

  const copy = async () => {
    await navigator.clipboard.writeText(`Subject: ${subject}\n\n${body}`);
    notify('Copied to clipboard', 'success');
  };

  const mailto = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  return (
    <div className="fixed inset-0 z-10 flex items-center justify-center bg-slate-900/50 p-4" onClick={onClose}>
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <h3 className="text-lg font-bold">{lead.organizationName}</h3>
            <a href={lead.website} target="_blank" rel="noreferrer" className="text-sm text-indigo-600 hover:underline">
              {lead.website}
            </a>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={lead.status} />
            <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
              ✕
            </button>
          </div>
        </div>

        <p className="mb-3 text-sm text-slate-600">{lead.description}</p>
        {lead.emailGeneratedBy === 'template' && (
          <p className="mb-3 rounded bg-amber-50 p-2 text-xs text-amber-800">
            The AI email step failed for this lead, so a basic template was used. Hit “Regenerate” to try again.
          </p>
        )}

        <div className="space-y-3">
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-500">To</span>
            <input className={field} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="no email found - add one" />
            {lead.emailSource && lead.contactEmail === email && (
              <span className="text-xs text-slate-400">found on {lead.emailSource}</span>
            )}
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-500">Subject</span>
            <input className={field} value={subject} onChange={(e) => setSubject(e.target.value)} />
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-500">Body</span>
            <textarea rows={12} className={`${field} font-mono`} value={body} onChange={(e) => setBody(e.target.value)} />
          </label>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={send}
            disabled={!!busy || !email || lead.status === 'Contacted'}
            className="rounded-lg bg-indigo-600 px-3 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-40"
          >
            {busy === 'send' ? 'Sending…' : lead.status === 'Contacted' ? 'Already sent' : 'Send email'}
          </button>
          <a
            href={mailto}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50"
            title="Opens your own mail app with this draft. Then use 'Mark sent' in the table."
          >
            Open in mail app
          </a>
          <button onClick={copy} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50">
            Copy
          </button>
          <button
            onClick={regenerate}
            disabled={!!busy}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50 disabled:opacity-40"
          >
            {busy === 'regen' ? 'Rewriting…' : 'Regenerate'}
          </button>
          <button
            onClick={save}
            disabled={!!busy || !dirty}
            className="ml-auto rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium hover:bg-slate-50 disabled:opacity-40"
          >
            Save edits
          </button>
        </div>
      </div>
    </div>
  );
}
